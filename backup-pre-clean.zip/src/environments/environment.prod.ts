
export const environment = {
  production: true,
  supabaseUrl: 'https://zvdohgdkdcyazicqjofl.supabase.co',
  supabaseAnonKey: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Inp2ZG9oZ2RrZGN5YXppY3Fqb2ZsIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTc4NjgyODAsImV4cCI6MjA3MzQ0NDI4MH0.IFLrJcNLQwhgK97c-4D4bUg5a-U4HILCqvJPPVizQ1c'
};
